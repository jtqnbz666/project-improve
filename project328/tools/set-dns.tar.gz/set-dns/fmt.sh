#!/bin/bash

gofmt -w ./
