#ifndef ROUTERREGISTER_H
#define ROUTERREGISTER_H

// 在此引用所有handle的头文件
#include "MoveHandle.h"

#endif 
